from django import forms
from .models import Items

class ItemsForm(forms.ModelForm):

    def __init__(self, *args, **kwargs):
        super(ItemsForm, self).__init__(*args, **kwargs)
        self.fields['name'].widget = forms.TextInput(attrs={'placeholder': 'Item Name', 'class': 'form-control m-2', 'required': True})
        self.fields['quantity'].widget = forms.NumberInput(attrs={'placeholder': 'Item Quantity', 'class': 'form-control m-2', 'required': True})
        self.fields['expiry_date'].widget = forms.DateInput(attrs={'class': 'form-control m-2', 'type': 'date', 'required': True})

    class Meta:
        model = Items
        fields = ('name', 'quantity', 'status', 'expiry_date')
