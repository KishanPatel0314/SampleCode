import sys
import json

orders = sys.argv[1]
dependencies = sys.argv[2]
output = sys.argv[3]

with open(orders) as file:
    orders_data = file.readlines()

parsed_order_data = {}
dependencies_dict = {}
for key, value in enumerate(orders_data):
    if key == 0: continue
    name = (value.split(",", 1)[1]).replace("\n", "")
    parsed_order_data[key] = name
    dependencies_dict[key] = {'id': key, 'name': name, 'dependencies': []}

with open(dependencies) as file:
    dependencies_data = file.readlines()

parsed_dependencies_data = {}
parent_keys = []
for key, value in enumerate(dependencies_data):
    if key == 0: continue
    values = value.split(",", 1)
    values[0] = int(values[0])
    if int(value[0]) not in parent_keys: parent_keys.append(int(value[0]))
    if values[0] in parsed_dependencies_data:
        parsed_dependencies_data[values[0]].append(int((values[1]).replace("\n", "")))
    else:
        parsed_dependencies_data[values[0]] = [int((values[1]).replace("\n", ""))]

output_data = {'orders':[]}

for key, value in parsed_dependencies_data.items():
    for key2, value2 in enumerate(value):
        dependencies_dict[key]['dependencies'].append(dependencies_dict[value2])

for key, value in parsed_dependencies_data.items():
    for key2, value2 in enumerate(value):
        if value2 in dependencies_dict:
            del dependencies_dict[value2]

for key, value in dependencies_dict.items():
    output_data['orders'].append(value)

output_json = json.dumps(output_data)
fp = open(output, "w")
fp.write(output_json)
fp.close()